﻿(function() {
  var drawMap, rintItemTemplate;

  drawMap = function(latlng) {
    var map, marker;
    map = new google.maps.Map(document.getElementById("map-canvas"), {
      zoom: 10,
      center: latlng,
      mapTypeId: google.maps.MapTypeId.ROADMAP
    });
    return marker = new google.maps.Marker({
      position: latlng,
      map: map,
      title: "Event Location"
    });
  };

  rintItemTemplate = $("[data-template='rint-item']").html();

  $("text");

  $(document).on("mobileinit", function() {
    $.mobile.toolbar.prototype.options.addBackBtn = true;
    $.mobile.buttonMarkup.hoverDelay = 0;
    $.mobile.defaultPageTransition = "none";
    return $.mobile.defaultDialogTransition = "none";
  });

  $(document).on("pagecreate", "#map-page", function() {
    return drawMap(new google.maps.LatLng(34.0983425, -118.3267434));
  });

}).call(this);
